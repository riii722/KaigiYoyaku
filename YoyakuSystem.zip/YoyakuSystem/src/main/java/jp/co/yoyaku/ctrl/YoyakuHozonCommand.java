package jp.co.yoyaku.ctrl;

public class YoyakuHozonCommand {

}
